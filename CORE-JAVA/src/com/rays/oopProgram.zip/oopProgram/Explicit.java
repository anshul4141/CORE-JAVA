package com.rays.oopProgram;

public class Explicit {

	public Explicit(String name) {

		System.out.println(name);

	}

}
