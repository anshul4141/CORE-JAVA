package com.rays.collectionProgram;

import java.util.ArrayList;
import java.util.Collection;

public class TestCollection {

	public static void main(String[] args) {

		Collection c = new ArrayList();
		
		c.add(1);
		c.add(2);
		c.add(3);
		c.add(4);
		
		System.out.println(c);

	}

}
