package com.rays.exceptionProgram;

public class BankException extends Exception {

	public BankException(String msg) {
		super(msg);
	}

}
