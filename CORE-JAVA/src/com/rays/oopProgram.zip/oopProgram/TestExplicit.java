package com.rays.oopProgram;

public class TestExplicit extends Explicit {

	public TestExplicit(String name) {

		super(name);

	}

	public static void main(String[] args) {

		TestExplicit t = new TestExplicit("Anshul");

	}

}
