package com.rays.oopProgram;

public final class TestImutable {

	private final String name;

	public TestImutable(String name) {

		this.name = name;
	}

	public String getName() {
		return name;
	}

}
