package com.rays.oopProgram;

public class TestImplicit extends Implicit {

	public TestImplicit() {

	}

	public static void main(String[] args) {

		TestImplicit t = new TestImplicit();
	}

}
