package com.rays.exceptionProgram;

public class LoginException extends Exception {

	public LoginException() {
		super("Invalid Login Id......");
	}

}
