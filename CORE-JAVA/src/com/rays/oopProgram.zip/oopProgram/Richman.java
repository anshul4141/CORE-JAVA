package com.rays.oopProgram;

public interface Richman {

	public void donationg(int i);

}
